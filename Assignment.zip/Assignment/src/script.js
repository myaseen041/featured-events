// Sample events data (simulating a JSON fetch)
const events = [
  {
    name: "Tech Conference 2025",
    date: "2025-06-15",
    time: "10:00 AM",
    location: "Lahore Expo Center",
    description: "A gathering of tech enthusiasts and startups."
  },
  {
    name: "Food Festival",
    date: "2025-06-20",
    time: "1:00 PM",
    location: "Gulberg Park",
    description: "Taste cuisines from around the world!"
  },
  {
    name: "Music Gala Night",
    date: "2025-06-25",
    time: "7:00 PM",
    location: "Liberty Grounds",
    description: "Live performances by local bands."
  },
  {
    name: "Startup Expo",
    date: "2025-07-01",
    time: "9:00 AM",
    location: "Innovation Hub",
    description: "Meet and greet with emerging startups."
  }
];

// Function to display events on the page
function renderEvents(filter = "") {
  const container = document.getElementById("events-container");
  container.innerHTML = ""; // Clear previous content

  // Filter and render matching events
  events.filter(event => event.name.toLowerCase().includes(filter.toLowerCase())).forEach(event => {
    const card = document.createElement("div");
    card.className = "col-md-4 mb-4";
    card.innerHTML = `
      <div class="card h-100">
        <div class="card-body">
          <h5 class="card-title">${event.name}</h5>
          <p><strong>Date:</strong> ${event.date} - ${event.time}</p>
          <p><strong>Location:</strong> ${event.location}</p>
          <p>${event.description}</p>
          <a href="#" class="btn btn-primary">Register</a>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// Event listener for live search
document.getElementById("searchInput").addEventListener("input", function(e) {
  renderEvents(e.target.value);
});

// Load events when the page is ready
document.addEventListener("DOMContentLoaded", () => {
  renderEvents();
});
